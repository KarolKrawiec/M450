package ch.tbz.library;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class LibraryServiceTest {

    @Mock
    private NotificationService notificationService;

    @Test
    void borrowBook_shouldSucceed_whenBookIsAvailable() {
        // Arrange
        LibraryService libraryService = new LibraryService(notificationService);
        Book book = new Book("1234", "TDD for Beginners", 1);
        Member member = new Member("M1", "Alice");

        // Act
        Loan loan = libraryService.borrowBook(member, book);

        // Assert
        assertThat(loan).isNotNull();
        assertThat(loan.getBook()).isEqualTo(book);
        assertThat(loan.getMember()).isEqualTo(member);
        assertThat(book.getAvailableCopies()).isEqualTo(0);
    }

    @Test
    void borrowBook_shouldFail_whenNoCopiesAreAvailable() {
        // Arrange
        LibraryService libraryService = new LibraryService(notificationService);
        Book book = new Book("1234", "TDD for Beginners", 0);
        Member member = new Member("M1", "Alice");

        // Act
        Loan loan = libraryService.borrowBook(member, book);

        // Assert
        assertThat(loan).isNull();
        assertThat(book.getAvailableCopies()).isEqualTo(0);
    }

    @Test
    void reserveBook_shouldCreateReservation_whenNoCopiesAreAvailable() {
        // Arrange
        LibraryService libraryService = new LibraryService(notificationService);
        Book book = new Book("1234", "TDD for Beginners", 0);
        Member member = new Member("M1", "Alice");

        // Act
        Reservation reservation = libraryService.reserveBook(member, book);

        // Assert
        assertThat(reservation).isNotNull();
        assertThat(reservation.getBook()).isEqualTo(book);
        assertThat(reservation.getMember()).isEqualTo(member);
        assertThat(libraryService.getReservationsForBook(book)).contains(reservation);
    }

    @Test
    void returnBook_shouldAssignToNextReservation_whenReservationExists() {
        // Arrange
        LibraryService libraryService = new LibraryService(notificationService);
        Book book = new Book("1234", "TDD for Beginners", 1);
        Member member1 = new Member("M1", "Alice");
        Member member2 = new Member("M2", "Bob");

        // First member borrows the only copy
        Loan loan = libraryService.borrowBook(member1, book);
        // Second member reserves it
        Reservation reservation = libraryService.reserveBook(member2, book);

        // Act
        libraryService.returnBook(loan);

        // Assert
        assertThat(loan.isReturned()).isTrue();
        // Since it was reserved, it should NOT be available, but rather assigned/pending for member2
        // In a real system, this might create a new Loan or mark the reservation as 'ready'
        // Let's assume it creates a Loan for the next person or we have a way to check it.
        // For simplicity: check if available copies is still 0 (because it's reserved for next)
        // and if it's removed from reservation queue.
        assertThat(book.getAvailableCopies()).isEqualTo(0);
        assertThat(libraryService.getReservationsForBook(book)).isEmpty();
    }

    @Test
    void returnBook_shouldIncreaseAvailableCopies_whenNoReservationExists() {
        // Arrange
        LibraryService libraryService = new LibraryService(notificationService);
        Book book = new Book("1234", "TDD for Beginners", 1);
        Member member = new Member("M1", "Alice");
        Loan loan = libraryService.borrowBook(member, book);

        // Act
        libraryService.returnBook(loan);

        // Assert
        assertThat(loan.isReturned()).isTrue();
        assertThat(book.getAvailableCopies()).isEqualTo(1);
    }

    @Test
    void isOverdue_shouldReturnTrue_whenDueDateHasPassed() {
        // Arrange
        Book book = new Book("1234", "TDD for Beginners", 1);
        Member member = new Member("M1", "Alice");
        // Create a loan with a due date in the past
        Loan loan = new Loan(book, member, LocalDate.now().minusDays(1));

        // Act & Assert
        assertThat(loan.isOverdue()).isTrue();
    }

    @Test
    void returnBook_shouldNotifyMember_whenBookIsAssignedToReservation() {
        // Arrange
        LibraryService libraryService = new LibraryService(notificationService);
        Book book = new Book("1234", "TDD for Beginners", 1);
        Member member1 = new Member("M1", "Alice");
        Member member2 = new Member("M2", "Bob");

        libraryService.borrowBook(member1, book);
        libraryService.reserveBook(member2, book);
        Loan loan = new Loan(book, member1, LocalDate.now().plusWeeks(4));

        // Act
        libraryService.returnBook(loan);

        // Assert
        verify(notificationService).notifyMember(eq(member2), anyString());
    }
}
