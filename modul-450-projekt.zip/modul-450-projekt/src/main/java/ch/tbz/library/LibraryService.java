package ch.tbz.library;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LibraryService {
    private final Map<String, List<Reservation>> reservations = new HashMap<>();
    private final NotificationService notificationService;

    public LibraryService(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    public Loan borrowBook(Member member, Book book) {
        if (book.getAvailableCopies() > 0) {
            book.setAvailableCopies(book.getAvailableCopies() - 1);
            return new Loan(book, member, LocalDate.now().plusWeeks(4));
        }
        return null;
    }

    public Reservation reserveBook(Member member, Book book) {
        Reservation reservation = new Reservation(book, member, LocalDateTime.now());
        reservations.computeIfAbsent(book.getIsbn(), k -> new ArrayList<>()).add(reservation);
        return reservation;
    }

    public List<Reservation> getReservationsForBook(Book book) {
        return reservations.getOrDefault(book.getIsbn(), new ArrayList<>());
    }

    public void returnBook(Loan loan) {
        loan.setReturned(true);
        Book book = loan.getBook();
        List<Reservation> bookReservations = reservations.get(book.getIsbn());

        if (bookReservations != null && !bookReservations.isEmpty()) {
            // Assign to next reservation: remove from queue and keep availableCopies at 0
            Reservation nextReservation = bookReservations.remove(0);
            if (notificationService != null) {
                notificationService.notifyMember(nextReservation.getMember(), 
                    "The book " + book.getTitle() + " is now available for you.");
            }
        } else {
            book.setAvailableCopies(book.getAvailableCopies() + 1);
        }
    }
}
