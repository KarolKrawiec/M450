package ch.tbz.library;

public interface NotificationService {
    void notifyMember(Member member, String message);
}
