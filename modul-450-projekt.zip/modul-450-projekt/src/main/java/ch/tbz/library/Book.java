package ch.tbz.library;

public class Book {
    private final String isbn;
    private final String title;
    private final int totalCopies;
    private int availableCopies;

    public Book(String isbn, String title, int totalCopies) {
        this.isbn = isbn;
        this.title = title;
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }
}
