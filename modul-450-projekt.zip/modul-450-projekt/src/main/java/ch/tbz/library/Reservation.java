package ch.tbz.library;

import java.time.LocalDateTime;

public class Reservation {
    private final Book book;
    private final Member member;
    private final LocalDateTime requestTime;

    public Reservation(Book book, Member member, LocalDateTime requestTime) {
        this.book = book;
        this.member = member;
        this.requestTime = requestTime;
    }

    public Book getBook() { return book; }
    public Member getMember() { return member; }
    public LocalDateTime getRequestTime() { return requestTime; }
}
