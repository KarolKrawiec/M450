# Testkonzept

## Teststrategie
Wir wenden **Test-Driven Development (TDD)** an. Jedes Feature wird nach dem Red-Green-Refactor Zyklus entwickelt.

## Test-Typen
- **Unit Tests**: Testen einzelner Klassen (Book, Member, Loan) in Isolierung.
- **Component Tests**: Testen des `LibraryService` und dessen Zusammenspiel mit anderen Komponenten (Repositories, Notification).

## Tools & Frameworks
- **JUnit 5**: Basis-Framework für alle Tests.
- **Mockito**: Mocking von Abhängigkeiten wie dem `NotificationService` oder `EmailService`.
- **AssertJ**: Für lesbare und aussagekräftige Assertions.
- **JaCoCo**: Automatisierte Messung der Code-Abdeckung (Ziel: >80%).

## Test-Szenarien (TDD Roadmap)
1. **Basis-Ausleihe**: 
   - Erfolgreich bei Verfügbarkeit.
   - Fehler wenn keine Exemplare vorhanden.
2. **Reservierung**:
   - Eintrag in Warteschlange wenn Buch vergriffen.
3. **Rückgabe-Logik**:
   - Automatische Zuweisung an den nächsten Reservierenden.
4. **Fristen**:
   - Korrekte Berechnung des Rückgabedatums.
   - Erkennung überfälliger Bücher.
