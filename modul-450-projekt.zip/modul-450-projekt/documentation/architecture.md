# Architektur-Dokumentation

## Domänenmodell
Das System basiert auf folgenden Kern-Entitäten:

```mermaid
classDiagram
    class Book {
        +String isbn
        +String title
        +int totalCopies
        +int availableCopies
    }
    class Member {
        +String memberId
        +String name
    }
    class Loan {
        +Book book
        +Member member
        +LocalDate dueDate
        +boolean isReturned
    }
    class Reservation {
        +Book book
        +Member member
        +LocalDateTime requestTime
    }
    class LibraryService {
        +borrowBook(Member, Book)
        +returnBook(Loan)
        +reserveBook(Member, Book)
    }

    LibraryService --> Book
    LibraryService --> Member
    LibraryService --> Loan
    LibraryService --> Reservation
    Loan o-- Book
    Loan o-- Member
    Reservation o-- Book
    Reservation o-- Member
```

## Komponentenübersicht
- **LibraryService**: Zentrale Business-Logik, welche die Regeln für Ausleihen und Reservierungen anwendet.
- **Repository (simuliert)**: Zur Speicherung von Daten im Speicher (für das Schulprojekt ausreichend).
- **Notification (Mocking Ziel)**: Ein Service, der Mitglieder benachrichtigt (wird in Tests gemockt).
