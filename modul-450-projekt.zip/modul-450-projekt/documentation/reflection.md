# Reflexion über TDD und Code Reviews

## Test-Driven Development (TDD)
Während der Entwicklung des Library Management Systems haben wir den TDD-Ansatz konsequent angewendet (Red-Green-Refactor).

### Erfahrungen
- **Vorteile**:
    - Man macht sich vor der Implementierung Gedanken über die Schnittstellen und das Verhalten des Codes.
    - Die Testabdeckung ist automatisch hoch.
    - Refactoring ist sicher, da Fehler sofort bemerkt werden.
- **Herausforderungen**:
    - Es erfordert Disziplin, nicht "vorab" zu programmieren.
    - Manchmal ist es schwierig, den "kleinstmöglichen Schritt" zu finden.

## Code Reviews
Obwohl dieses Projekt in einer simulierten Umgebung erstellt wurde, haben wir den Workflow mit Feature Branches und Pull Requests (simuliert) geplant.

### Erkenntnisse
- **Qualität**: Code Reviews helfen, Clean Code Prinzipien einzuhalten.
- **Wissenstransfer**: Teammitglieder lernen voneinander, indem sie den Code der anderen challenged.
- **Konstruktivität**: Kommentare sollten immer lösungsorientiert sein ("Was hältst du davon, wenn wir hier XYZ machen?" statt "Das ist falsch").

## Fazit
TDD und Code Reviews verlangsamen die initiale Entwicklung zwar gefühlt etwas, sparen aber im späteren Verlauf durch weniger Bugs und eine bessere Wartbarkeit massiv Zeit ein.
