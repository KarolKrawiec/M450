<?php
/**
 * Created by PhpStorm.
 * User: s.kemper
 * Date: 29.03.2022
 * Time: 22:05
 *
 * This class does a lot of things... but has no productive purpose.
 * The only purpose of this class is to teach the basic functions
 * of PHP and how to use them.
 */

class MyFancyClass
{
    public function shortString($text, $length, $ending = '...') {
        // Return false if ending is longer than the allowed length
        if (strlen($ending) > $length) {
            return false;
        }
        
        // If text is already shorter or equal to length, return it as is
        if (strlen($text) <= $length) {
            return $text;
        }
        
        // Truncate the text and add the ending
        $maxTextLength = $length - strlen($ending);
        return substr($text, 0, $maxTextLength) . $ending;
    }

    public function calcAverage($values) {
        // Return 0 for empty array
        if (empty($values)) {
            return 0;
        }
        
        // Check if all values are numeric and calculate sum
        $sum = 0;
        foreach ($values as $value) {
            if (!is_numeric($value)) {
                return false;
            }
            $sum += floatval($value);
        }
        
        // Calculate and return average
        return $sum / count($values);
    }

    public function getOpposite($value, $delimiter = ',') {
        // If value is an array, convert to string (implode)
        if (is_array($value)) {
            return implode($delimiter, $value);
        }
        
        // If value is a string, convert to array (explode)
        if (is_string($value)) {
            return explode($delimiter, $value);
        }
        
        // Return false for invalid input types (e.g., objects)
        return false;
    }
}