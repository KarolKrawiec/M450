<?php
/**
 * Manual Test Script for MyFancyClass
 * Run this script with: php manual_test.php
 * This allows you to test the implementation without PHPUnit
 */

require_once('../Application/MyFancyClass.php');

$myFancyClass = new MyFancyClass();
$passed = 0;
$failed = 0;

echo "========================================\n";
echo "Manual Testing for MyFancyClass\n";
echo "========================================\n\n";

// Test 1: shortString()
echo "--- Testing shortString() ---\n";

$result1 = $myFancyClass->shortString('', 100);
if ($result1 === '') {
    echo " PASS: Empty string returns empty\n";
    $passed++;
} else {
    echo " FAIL: Empty string test\n";
    $failed++;
}

$text35 = 'Ich bin Text mit 35 Char L�nge (35)';
$result2 = $myFancyClass->shortString($text35, 100);
if ($result2 === $text35) {
    echo " PASS: Short text returns unchanged\n";
    $passed++;
} else {
    echo " FAIL: Short text test\n";
    $failed++;
}

$text130 = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam';
$result3 = $myFancyClass->shortString($text130, 100);
$expected3 = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt u...';
if ($result3 === $expected3) {
    echo " PASS: Long text truncated correctly\n";
    $passed++;
} else {
    echo " FAIL: Long text truncation\n";
    echo "  Expected: $expected3\n";
    echo "  Got:      $result3\n";
    $failed++;
}

$result4 = $myFancyClass->shortString('text', 2, 'I am a end and a complete sentence.');
if ($result4 === false) {
    echo " PASS: Returns false when ending > length\n";
    $passed++;
} else {
    echo " FAIL: Should return false when ending too long\n";
    $failed++;
}

echo "\n--- Testing calcAverage() ---\n";

$result5 = $myFancyClass->calcAverage([]);
if ($result5 === 0) {
    echo " PASS: Empty array returns 0\n";
    $passed++;
} else {
    echo " FAIL: Empty array test\n";
    $failed++;
}

$result6 = $myFancyClass->calcAverage([4.5, 5.0, 5.5]);
if ($result6 === 5.0) {
    echo " PASS: Correct average calculation\n";
    $passed++;
} else {
    echo " FAIL: Average calculation\n";
    echo "  Expected: 5.0\n";
    echo "  Got:      $result6\n";
    $failed++;
}

$result7 = $myFancyClass->calcAverage(['4.5', '5.0', '5.5']);
if ($result7 === 5.0) {
    echo " PASS: Handles string numbers\n";
    $passed++;
} else {
    echo " FAIL: String numbers test\n";
    $failed++;
}

$result8 = $myFancyClass->calcAverage(['3.44', 'bestanden', 'nicht bewertbar']);
if ($result8 === false) {
    echo " PASS: Returns false for non-numeric values\n";
    $passed++;
} else {
    echo " FAIL: Should return false for non-numeric\n";
    $failed++;
}

echo "\n--- Testing getOpposite() ---\n";

$result9 = $myFancyClass->getOpposite([4.5, 5.0, 5.5]);
if ($result9 === '4.5,5,5.5') {
    echo " PASS: Array to string conversion\n";
    $passed++;
} else {
    echo " FAIL: Array to string\n";
    echo "  Expected: '4.5,5,5.5'\n";
    echo "  Got:      '$result9'\n";
    $failed++;
}

$stringList = 'Apfel,Birne,Pflaume,Pfirsich';
$result10 = $myFancyClass->getOpposite($stringList);
if (is_array($result10) && count($result10) === 4) {
    echo " PASS: String to array conversion\n";
    $passed++;
} else {
    echo " FAIL: String to array\n";
    $failed++;
}

// Bidirectional test
$result11 = $myFancyClass->getOpposite($myFancyClass->getOpposite($stringList));
if ($result11 === $stringList) {
    echo " PASS: Bidirectional conversion works\n";
    $passed++;
} else {
    echo " FAIL: Bidirectional conversion\n";
    echo "  Expected: $stringList\n";
    echo "  Got:      $result11\n";
    $failed++;
}

$result12 = $myFancyClass->getOpposite($myFancyClass);
if ($result12 === false) {
    echo " PASS: Returns false for invalid input\n";
    $passed++;
} else {
    echo " FAIL: Should return false for objects\n";
    $failed++;
}

echo "\n========================================\n";
echo "Test Results: $passed passed, $failed failed\n";
if ($failed === 0) {
    echo " All tests passed!\n";
} else {
    echo "  Some tests failed. Please review the implementation.\n";
}
echo "========================================\n";
